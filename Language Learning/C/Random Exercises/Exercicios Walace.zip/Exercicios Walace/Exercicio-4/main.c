//RESPOSTAS PARA O EXERCICIOS



//A) O melhor loop � o for

//B) O melhor loop � o do while

//C) O melhor loop � o whilee
