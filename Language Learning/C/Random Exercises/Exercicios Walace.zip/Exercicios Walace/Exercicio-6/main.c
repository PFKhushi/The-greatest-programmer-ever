#include <stdio.h>
#include <stdlib.h>

int main()
{
    //receber numero de habitante, fazer um loop de votacao e calcular o vencedor


    int a, b, c, pessoas;
    printf("")
    return 0;
}
